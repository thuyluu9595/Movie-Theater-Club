package com.example.MovieTheaterAPI.discount.dto;

import lombok.Data;

@Data
public class DiscountUpdateDTO {
    private float percent;
}
